import React, { useState } from 'react';
import { useQuiz } from './hooks/useQuiz';
import { useTheme } from './hooks/useTheme';
import StartScreen from './components/StartScreen';
import SetSelectionScreen from './components/SetSelectionScreen';
import QuestionCard from './components/QuestionCard';
import FeedbackMessage from './components/FeedbackMessage';
import ResultsScreen from './components/ResultsScreen';
import StatsScreen from './components/StatsScreen';
import ThemeToggle from './components/ThemeToggle';

type AppState = 'start' | 'sets' | 'quiz' | 'results' | 'stats';

function App() {
  const [appState, setAppState] = useState<AppState>('start');
  const { isDark, toggleTheme } = useTheme();
  const {
    quizSets,
    quizState,
    loading,
    error,
    selectQuizSet,
    selectAnswer,
    nextQuestion,
    restartQuiz,
    resetToSetSelection,
    getCurrentStats
  } = useQuiz();

  const handleStartQuiz = () => {
    setAppState('sets');
  };

  const handleSelectSet = (set: any) => {
    selectQuizSet(set);
    setAppState('quiz');
  };

  const handleViewStats = () => {
    setAppState('stats');
  };

  const handleBackToHome = () => {
    setAppState('start');
  };

  const handleBackToSets = () => {
    resetToSetSelection();
    setAppState('sets');
  };

  const handleRestart = () => {
    restartQuiz();
    setAppState('quiz');
  };

  const handleNextQuestion = () => {
    nextQuestion();
    if (quizState.currentQuestionIndex + 1 >= 10) {
      setAppState('results');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-300">Loading quiz questions...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 dark:text-red-400 mb-4">Error: {error}</p>
          <button
            onClick={() => window.location.reload()}
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="fixed top-4 right-4 z-50">
        <ThemeToggle isDark={isDark} onToggle={toggleTheme} />
      </div>

      {appState === 'start' && (
        <StartScreen onStart={handleStartQuiz} onViewStats={handleViewStats} />
      )}

      {appState === 'sets' && (
        <SetSelectionScreen 
          sets={quizSets} 
          onSelectSet={handleSelectSet} 
          onBack={handleBackToHome}
        />
      )}

      {appState === 'quiz' && quizState.selectedSet && (
        <>
          <QuestionCard
            question={quizState.selectedSet.questions[quizState.currentQuestionIndex]}
            questionNumber={quizState.currentQuestionIndex + 1}
            totalQuestions={10}
            selectedAnswer={quizState.selectedAnswer}
            showFeedback={quizState.showFeedback}
            onAnswerSelect={selectAnswer}
            setTitle={quizState.selectedSet.title}
          />
          {quizState.showFeedback && (
            <FeedbackMessage
              isCorrect={quizState.selectedAnswer === quizState.selectedSet.questions[quizState.currentQuestionIndex].correctIndex}
              onNext={handleNextQuestion}
              isLastQuestion={quizState.currentQuestionIndex + 1 >= 10}
            />
          )}
        </>
      )}

      {appState === 'results' && (
        <ResultsScreen
          stats={getCurrentStats()}
          onRestart={handleRestart}
          onBackToSets={handleBackToSets}
          onBackToHome={handleBackToHome}
        />
      )}

      {appState === 'stats' && (
        <StatsScreen onBack={handleBackToHome} />
      )}
    </div>
  );
}

export default App;