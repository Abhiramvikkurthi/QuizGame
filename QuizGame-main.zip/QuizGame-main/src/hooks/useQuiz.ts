import { useState, useEffect } from 'react';
import { Question, QuizState, GameStats, QuizSet } from '../types/quiz';
import { parseCSV } from '../utils/csvParser';
import { createQuizSets } from '../utils/quizSets';
import { saveGameStats } from '../utils/storage';

export const useQuiz = () => {
  const [allQuestions, setAllQuestions] = useState<Question[]>([]);
  const [quizSets, setQuizSets] = useState<QuizSet[]>([]);
  const [quizState, setQuizState] = useState<QuizState>({
    currentQuestionIndex: 0,
    score: 0,
    answers: [],
    isComplete: false,
    showFeedback: false,
    selectedAnswer: null,
    selectedSet: null
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadQuestions();
  }, []);

  const loadQuestions = async () => {
    try {
      setLoading(true);
      const response = await fetch('/unique_real_life_quiz_questions.csv');
      if (!response.ok) {
        throw new Error('Failed to load questions');
      }
      const csvText = await response.text();
      const parsedQuestions = parseCSV(csvText);
      
      setAllQuestions(parsedQuestions);
      const sets = createQuizSets(parsedQuestions);
      setQuizSets(sets);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load questions');
    } finally {
      setLoading(false);
    }
  };

  const selectQuizSet = (set: QuizSet) => {
    setQuizState({
      currentQuestionIndex: 0,
      score: 0,
      answers: new Array(10).fill(null),
      isComplete: false,
      showFeedback: false,
      selectedAnswer: null,
      selectedSet: set
    });
  };

  const selectAnswer = (answerIndex: number) => {
    if (quizState.showFeedback || !quizState.selectedSet) return;

    const newAnswers = [...quizState.answers];
    newAnswers[quizState.currentQuestionIndex] = answerIndex;

    const currentQuestion = quizState.selectedSet.questions[quizState.currentQuestionIndex];
    const isCorrect = answerIndex === currentQuestion.correctIndex;
    const newScore = isCorrect ? quizState.score + 1 : quizState.score;

    setQuizState(prev => ({
      ...prev,
      selectedAnswer: answerIndex,
      showFeedback: true,
      answers: newAnswers,
      score: newScore
    }));
  };

  const nextQuestion = () => {
    if (!quizState.selectedSet) return;
    
    const nextIndex = quizState.currentQuestionIndex + 1;
    
    if (nextIndex >= 10) {
      // Quiz complete
      const stats: GameStats = {
        totalQuestions: 10,
        correctAnswers: quizState.score,
        percentage: Math.round((quizState.score / 10) * 100),
        completedAt: new Date(),
        setId: quizState.selectedSet.id,
        setTitle: quizState.selectedSet.title
      };
      
      saveGameStats(stats);
      
      setQuizState(prev => ({
        ...prev,
        isComplete: true
      }));
    } else {
      setQuizState(prev => ({
        ...prev,
        currentQuestionIndex: nextIndex,
        showFeedback: false,
        selectedAnswer: null
      }));
    }
  };

  const restartQuiz = () => {
    if (!quizState.selectedSet) return;
    
    // Shuffle questions in the current set for variety
    const shuffledQuestions = [...quizState.selectedSet.questions].sort(() => Math.random() - 0.5);
    const updatedSet = { ...quizState.selectedSet, questions: shuffledQuestions };
    
    setQuizState({
      currentQuestionIndex: 0,
      score: 0,
      answers: new Array(10).fill(null),
      isComplete: false,
      showFeedback: false,
      selectedAnswer: null,
      selectedSet: updatedSet
    });
  };

  const resetToSetSelection = () => {
    setQuizState({
      currentQuestionIndex: 0,
      score: 0,
      answers: [],
      isComplete: false,
      showFeedback: false,
      selectedAnswer: null,
      selectedSet: null
    });
  };

  const getCurrentStats = (): GameStats => ({
    totalQuestions: 10,
    correctAnswers: quizState.score,
    percentage: Math.round((quizState.score / 10) * 100),
    completedAt: new Date(),
    setId: quizState.selectedSet?.id || 0,
    setTitle: quizState.selectedSet?.title || ''
  });

  return {
    allQuestions,
    quizSets,
    quizState,
    loading,
    error,
    selectQuizSet,
    selectAnswer,
    nextQuestion,
    restartQuiz,
    resetToSetSelection,
    getCurrentStats
  };
};