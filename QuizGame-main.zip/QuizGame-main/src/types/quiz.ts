export interface Question {
  question: string;
  option1: string;
  option2: string;
  option3: string;
  option4: string;
  correctIndex: number;
  category?: string;
}

export interface QuizSet {
  id: number;
  title: string;
  description: string;
  questions: Question[];
  difficulty: 'Easy' | 'Medium' | 'Hard';
  category: string;
}

export interface QuizState {
  currentQuestionIndex: number;
  score: number;
  answers: (number | null)[];
  isComplete: boolean;
  showFeedback: boolean;
  selectedAnswer: number | null;
  selectedSet: QuizSet | null;
}

export interface GameStats {
  totalQuestions: number;
  correctAnswers: number;
  percentage: number;
  completedAt: Date;
  setId: number;
  setTitle: string;
}