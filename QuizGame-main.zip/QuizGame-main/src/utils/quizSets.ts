import { Question, QuizSet } from '../types/quiz';

export const createQuizSets = (allQuestions: Question[]): QuizSet[] => {
  // Shuffle all questions first
  const shuffled = [...allQuestions].sort(() => Math.random() - 0.5);
  
  const sets: QuizSet[] = [
    {
      id: 1,
      title: "Everyday Essentials",
      description: "Common situations you face daily",
      difficulty: "Easy",
      category: "General",
      questions: shuffled.slice(0, 10)
    },
    {
      id: 2,
      title: "Health & Safety",
      description: "Medical emergencies and safety scenarios",
      difficulty: "Medium",
      category: "Health",
      questions: shuffled.slice(10, 20)
    },
    {
      id: 3,
      title: "Tech Troubles",
      description: "Technology and digital life challenges",
      difficulty: "Easy",
      category: "Technology",
      questions: shuffled.slice(20, 30)
    },
    {
      id: 4,
      title: "Money Matters",
      description: "Financial decisions and banking issues",
      difficulty: "Medium",
      category: "Finance",
      questions: shuffled.slice(30, 40)
    },
    {
      id: 5,
      title: "Travel & Transport",
      description: "Airport, driving, and travel situations",
      difficulty: "Medium",
      category: "Travel",
      questions: shuffled.slice(40, 50)
    },
    {
      id: 6,
      title: "Workplace Wisdom",
      description: "Professional and job-related scenarios",
      difficulty: "Hard",
      category: "Work",
      questions: shuffled.slice(50, 60)
    },
    {
      id: 7,
      title: "Social Situations",
      description: "Interpersonal and social challenges",
      difficulty: "Medium",
      category: "Social",
      questions: shuffled.slice(60, 70)
    },
    {
      id: 8,
      title: "Emergency Response",
      description: "Crisis management and emergency situations",
      difficulty: "Hard",
      category: "Emergency",
      questions: shuffled.slice(70, 80)
    },
    {
      id: 9,
      title: "Home & Family",
      description: "Household and family-related decisions",
      difficulty: "Easy",
      category: "Family",
      questions: shuffled.slice(80, 90)
    },
    {
      id: 10,
      title: "Mixed Challenge",
      description: "A variety of challenging scenarios",
      difficulty: "Hard",
      category: "Mixed",
      questions: shuffled.slice(90, 100)
    }
  ];

  return sets;
};

export const getDifficultyColor = (difficulty: string): string => {
  switch (difficulty) {
    case 'Easy':
      return 'text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/20';
    case 'Medium':
      return 'text-yellow-600 dark:text-yellow-400 bg-yellow-100 dark:bg-yellow-900/20';
    case 'Hard':
      return 'text-red-600 dark:text-red-400 bg-red-100 dark:bg-red-900/20';
    default:
      return 'text-gray-600 dark:text-gray-400 bg-gray-100 dark:bg-gray-900/20';
  }
};

export const getCategoryIcon = (category: string): string => {
  switch (category) {
    case 'Health':
      return '🏥';
    case 'Technology':
      return '💻';
    case 'Finance':
      return '💰';
    case 'Travel':
      return '✈️';
    case 'Work':
      return '💼';
    case 'Social':
      return '👥';
    case 'Emergency':
      return '🚨';
    case 'Family':
      return '🏠';
    case 'Mixed':
      return '🎯';
    default:
      return '📝';
  }
};