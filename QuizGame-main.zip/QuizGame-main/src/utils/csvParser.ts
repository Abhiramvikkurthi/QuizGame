import { Question } from '../types/quiz';

export const parseCSV = (csvText: string): Question[] => {
  const lines = csvText.trim().split('\n');
  const headers = lines[0].split(',');
  
  return lines.slice(1).map(line => {
    const values = parseCSVLine(line);
    return {
      question: values[0],
      option1: values[1],
      option2: values[2],
      option3: values[3],
      option4: values[4],
      correctIndex: parseInt(values[5]),
      category: getCategoryFromQuestion(values[0])
    };
  });
};

const parseCSVLine = (line: string): string[] => {
  const result = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  
  result.push(current.trim());
  return result;
};

const getCategoryFromQuestion = (question: string): string => {
  const lowerQuestion = question.toLowerCase();
  
  if (lowerQuestion.includes('restaurant') || lowerQuestion.includes('food') || lowerQuestion.includes('cooking')) {
    return 'food';
  }
  if (lowerQuestion.includes('internet') || lowerQuestion.includes('computer') || lowerQuestion.includes('laptop') || lowerQuestion.includes('phone')) {
    return 'tech';
  }
  if (lowerQuestion.includes('pain') || lowerQuestion.includes('fever') || lowerQuestion.includes('medical') || lowerQuestion.includes('dizzy')) {
    return 'health';
  }
  if (lowerQuestion.includes('atm') || lowerQuestion.includes('card') || lowerQuestion.includes('cash') || lowerQuestion.includes('money')) {
    return 'finance';
  }
  if (lowerQuestion.includes('driving') || lowerQuestion.includes('accident') || lowerQuestion.includes('travel') || lowerQuestion.includes('airport')) {
    return 'transport';
  }
  if (lowerQuestion.includes('fire') || lowerQuestion.includes('emergency') || lowerQuestion.includes('safety')) {
    return 'safety';
  }
  if (lowerQuestion.includes('job') || lowerQuestion.includes('interview') || lowerQuestion.includes('office') || lowerQuestion.includes('work')) {
    return 'work';
  }
  
  return 'general';
};