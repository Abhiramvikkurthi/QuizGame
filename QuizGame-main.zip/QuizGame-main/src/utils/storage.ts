import { GameStats } from '../types/quiz';

const STORAGE_KEY = 'quiz-game-stats';

export const saveGameStats = (stats: GameStats): void => {
  try {
    const existingStats = getGameStats();
    const updatedStats = [...existingStats, stats].slice(-50); // Keep last 50 games
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedStats));
  } catch (error) {
    console.error('Failed to save game stats:', error);
  }
};

export const getGameStats = (): GameStats[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Failed to load game stats:', error);
    return [];
  }
};

export const getBestScore = (): number => {
  const stats = getGameStats();
  return stats.length > 0 ? Math.max(...stats.map(s => s.percentage)) : 0;
};

export const getAverageScore = (): number => {
  const stats = getGameStats();
  if (stats.length === 0) return 0;
  const total = stats.reduce((sum, s) => sum + s.percentage, 0);
  return Math.round(total / stats.length);
};