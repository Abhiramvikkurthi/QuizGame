import React from 'react';
import { ArrowLeft, Play, Star, Clock } from 'lucide-react';
import { QuizSet, getDifficultyColor, getCategoryIcon } from '../utils/quizSets';

interface SetSelectionScreenProps {
  sets: QuizSet[];
  onSelectSet: (set: QuizSet) => void;
  onBack: () => void;
}

const SetSelectionScreen: React.FC<SetSelectionScreenProps> = ({ sets, onSelectSet, onBack }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="p-2 rounded-lg bg-white dark:bg-gray-800 shadow-md hover:shadow-lg transition-shadow duration-200 mr-4"
          >
            <ArrowLeft className="w-6 h-6 text-gray-600 dark:text-gray-300" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              Choose Your Quiz Set
            </h1>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
              Select from 10 different sets, each with 10 unique questions
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {sets.map((set) => (
            <div
              key={set.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer overflow-hidden"
              onClick={() => onSelectSet(set)}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="text-3xl">{getCategoryIcon(set.category)}</div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                        Set {set.id}: {set.title}
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">
                        {set.description}
                      </p>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDifficultyColor(set.difficulty)}`}>
                    {set.difficulty}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4" />
                      <span>10 Questions</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>~5 mins</span>
                    </div>
                  </div>
                  
                  <button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200 flex items-center space-x-2">
                    <Play className="w-4 h-4" />
                    <span>Start</span>
                  </button>
                </div>
              </div>
              
              <div className="h-2 bg-gradient-to-r from-blue-500 to-purple-600"></div>
            </div>
          ))}
        </div>

        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Each set contains 10 carefully selected questions • Choose based on your interests
          </p>
        </div>
      </div>
    </div>
  );
};

export default SetSelectionScreen;