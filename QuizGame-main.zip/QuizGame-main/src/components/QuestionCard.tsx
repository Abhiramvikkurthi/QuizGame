import React from 'react';
import { Question } from '../types/quiz';
import CategoryIcon from './CategoryIcon';
import ProgressBar from './ProgressBar';

interface QuestionCardProps {
  question: Question;
  questionNumber: number;
  totalQuestions: number;
  selectedAnswer: number | null;
  showFeedback: boolean;
  onAnswerSelect: (answerIndex: number) => void;
  setTitle?: string;
}

const QuestionCard: React.FC<QuestionCardProps> = ({
  question,
  questionNumber,
  totalQuestions,
  selectedAnswer,
  showFeedback,
  onAnswerSelect,
  setTitle
}) => {
  const options = [question.option1, question.option2, question.option3, question.option4];

  const getOptionClassName = (index: number) => {
    let baseClass = "w-full p-4 text-left rounded-xl border-2 transition-all duration-200 transform hover:scale-102 ";
    
    if (!showFeedback) {
      if (selectedAnswer === index) {
        baseClass += "border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-900 dark:text-blue-100";
      } else {
        baseClass += "border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 hover:border-gray-300 dark:hover:border-gray-500 text-gray-900 dark:text-white";
      }
    } else {
      if (index === question.correctIndex) {
        baseClass += "border-green-500 bg-green-50 dark:bg-green-900/20 text-green-900 dark:text-green-100";
      } else if (selectedAnswer === index && index !== question.correctIndex) {
        baseClass += "border-red-500 bg-red-50 dark:bg-red-900/20 text-red-900 dark:text-red-100";
      } else {
        baseClass += "border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 text-gray-600 dark:text-gray-400";
      }
    }
    
    return baseClass;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                Question {questionNumber} of {totalQuestions}
              </span>
              {setTitle && (
                <span className="text-xs bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-200 px-2 py-1 rounded-full">
                  {setTitle}
                </span>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <CategoryIcon category={question.category || 'general'} className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              <span className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                {question.category || 'general'}
              </span>
            </div>
          </div>
          <ProgressBar current={questionNumber} total={totalQuestions} />
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 leading-relaxed">
            {question.question}
          </h2>

          <div className="space-y-4">
            {options.map((option, index) => (
              <button
                key={index}
                onClick={() => !showFeedback && onAnswerSelect(index)}
                disabled={showFeedback}
                className={getOptionClassName(index)}
              >
                <div className="flex items-center">
                  <span className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center text-sm font-semibold mr-4">
                    {String.fromCharCode(65 + index)}
                  </span>
                  <span className="flex-1">{option}</span>
                </div>
              </button>
            ))}
          </div>

          {showFeedback && (
            <div className="mt-6 p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
              <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                Real-Life Tip:
              </h3>
              <p className="text-blue-800 dark:text-blue-200 text-sm">
                {getLifeTip(question)}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const getLifeTip = (question: Question): string => {
  const tips: { [key: string]: string } = {
    'restaurant': 'Always communicate politely with service staff. They are more likely to help when approached respectfully.',
    'internet': 'Basic troubleshooting like restarting your router can solve 80% of connectivity issues.',
    'phone': 'Being honest and helpful when finding lost items builds community trust and good karma.',
    'atm': 'Contact your bank immediately if an ATM malfunctions. They have procedures to help retrieve your card.',
    'cooking': 'For cuts, clean the wound first, apply pressure to stop bleeding, then bandage properly.',
    'travel': 'Having backup transportation options is always wise for urgent situations.',
    'interview': 'Honesty and quick problem-solving during interviews often impress employers more than perfection.',
    'chest pain': 'Never ignore chest pain. When in doubt, seek immediate medical attention.',
    'delivery': 'Returning misdelivered items to the sender helps maintain trust in delivery systems.',
    'laptop': 'When electronics get wet, immediately power off and disconnect to prevent short circuits.',
    'airport': 'Flight delays are opportunities to be productive or rest. Stay positive and make the best of it.',
    'card': 'Always have backup payment methods and know your bank\'s contact information.',
    'driving': 'Never hesitate to speak up about dangerous driving. Safety comes first.',
    'fire': 'In emergencies, stay calm and follow evacuation procedures. Panic causes more harm.',
    'shoplifting': 'Report suspicious activities to proper authorities rather than confronting directly.',
    'dizzy': 'Heat exhaustion is serious. Find shade, hydrate, and rest immediately.',
    'prize': 'If something seems too good to be true, it probably is. Always verify before clicking links.',
    'accident': 'In emergencies, calling professional help first can save lives.',
    'fever': 'High fevers in children require immediate medical attention, especially at night.',
    'computer': 'Regular saving and backups prevent data loss. Make it a habit.'
  };

  const questionLower = question.question.toLowerCase();
  for (const [key, tip] of Object.entries(tips)) {
    if (questionLower.includes(key)) {
      return tip;
    }
  }
  
  return 'Good decision-making comes from experience and thinking through consequences before acting.';
};

export default QuestionCard;