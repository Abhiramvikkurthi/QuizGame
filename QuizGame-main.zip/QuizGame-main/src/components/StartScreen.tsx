import React from 'react';
import { Play, Trophy, BarChart3 } from 'lucide-react';
import { getBestScore, getAverageScore } from '../utils/storage';

interface StartScreenProps {
  onStart: () => void;
  onViewStats: () => void;
}

const StartScreen: React.FC<StartScreenProps> = ({ onStart, onViewStats }) => {
  const bestScore = getBestScore();
  const averageScore = getAverageScore();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-6">
            <Play className="w-10 h-10 text-white ml-1" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Real-Life Quiz
          </h1>
          <p className="text-gray-600 dark:text-gray-300 text-lg">
            Test your decision-making skills with 100 real-world scenarios
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
            Your Stats
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <Trophy className="w-6 h-6 text-blue-600 dark:text-blue-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {bestScore}%
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Best Score
              </div>
            </div>
            <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <BarChart3 className="w-6 h-6 text-purple-600 dark:text-purple-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                {averageScore}%
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Average
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <button
            onClick={onStart}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg"
          >
            Start Quiz
          </button>
          
          <button
            onClick={onViewStats}
            className="w-full bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-900 dark:text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200"
          >
            View Statistics
          </button>
        </div>

        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            100 unique scenarios • Multiple choice • Instant feedback
          </p>
        </div>
      </div>
    </div>
  );
};

export default StartScreen;