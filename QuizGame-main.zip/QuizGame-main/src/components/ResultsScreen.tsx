import React from 'react';
import { Trophy, RotateCcw, Share2, TrendingUp, ArrowLeft } from 'lucide-react';
import { GameStats } from '../types/quiz';

interface ResultsScreenProps {
  stats: GameStats;
  onRestart: () => void;
  onBackToSets: () => void;
  onBackToHome: () => void;
}

const ResultsScreen: React.FC<ResultsScreenProps> = ({ stats, onRestart, onBackToSets, onBackToHome }) => {
  const getPerformanceMessage = (percentage: number) => {
    if (percentage >= 90) return { message: "Outstanding! You're a real-life expert! 🏆", color: "text-yellow-600 dark:text-yellow-400" };
    if (percentage >= 80) return { message: "Excellent work! Great decision-making skills! 🌟", color: "text-green-600 dark:text-green-400" };
    if (percentage >= 70) return { message: "Good job! You're on the right track! 👍", color: "text-blue-600 dark:text-blue-400" };
    if (percentage >= 60) return { message: "Not bad! Room for improvement! 📈", color: "text-orange-600 dark:text-orange-400" };
    return { message: "Keep practicing! You'll get better! 💪", color: "text-red-600 dark:text-red-400" };
  };

  const performance = getPerformanceMessage(stats.percentage);

  const shareScore = () => {
    const text = `I just scored ${stats.percentage}% on "${stats.setTitle}" in the Real-Life Scenario Quiz! Test your decision-making skills too!`;
    if (navigator.share) {
      navigator.share({
        title: 'Real-Life Quiz Results',
        text: text,
        url: window.location.href
      });
    } else {
      const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text + ' ' + window.location.href)}`;
      window.open(whatsappUrl, '_blank');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-6">
            <Trophy className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Quiz Complete!
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mb-2">
            {stats.setTitle}
          </p>
          <p className={`text-lg font-semibold ${performance.color}`}>
            {performance.message}
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 mb-6">
          <div className="text-center mb-6">
            <div className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-600 mb-2">
              {stats.percentage}%
            </div>
            <p className="text-gray-600 dark:text-gray-300">
              {stats.correctAnswers} out of {stats.totalQuestions} correct
            </p>
          </div>

          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {stats.totalQuestions}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">
                Questions
              </div>
            </div>
            <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                {stats.correctAnswers}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">
                Correct
              </div>
            </div>
            <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
              <div className="text-2xl font-bold text-red-600 dark:text-red-400">
                {stats.totalQuestions - stats.correctAnswers}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">
                Wrong
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <button
            onClick={shareScore}
            className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2"
          >
            <Share2 className="w-5 h-5" />
            <span>Share Score</span>
          </button>
          
          <button
            onClick={onRestart}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2"
          >
            <RotateCcw className="w-5 h-5" />
            <span>Try This Set Again</span>
          </button>
          
          <button
            onClick={onBackToSets}
            className="w-full bg-purple-200 dark:bg-purple-700 hover:bg-purple-300 dark:hover:bg-purple-600 text-purple-900 dark:text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 flex items-center justify-center space-x-2"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Choose Another Set</span>
          </button>
          
          <button
            onClick={onBackToHome}
            className="w-full bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-900 dark:text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 flex items-center justify-center space-x-2"
          >
            <TrendingUp className="w-5 h-5" />
            <span>View Statistics</span>
          </button>
        </div>

        <div className="mt-6 text-center">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Completed on {stats.completedAt.toLocaleDateString()}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ResultsScreen;