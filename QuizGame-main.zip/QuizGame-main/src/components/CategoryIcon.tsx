import React from 'react';
import { 
  Utensils, 
  Laptop, 
  Heart, 
  CreditCard, 
  Car, 
  Shield, 
  Briefcase, 
  HelpCircle 
} from 'lucide-react';

interface CategoryIconProps {
  category: string;
  className?: string;
}

const CategoryIcon: React.FC<CategoryIconProps> = ({ category, className = "w-6 h-6" }) => {
  const iconProps = { className };

  switch (category) {
    case 'food':
      return <Utensils {...iconProps} />;
    case 'tech':
      return <Laptop {...iconProps} />;
    case 'health':
      return <Heart {...iconProps} />;
    case 'finance':
      return <CreditCard {...iconProps} />;
    case 'transport':
      return <Car {...iconProps} />;
    case 'safety':
      return <Shield {...iconProps} />;
    case 'work':
      return <Briefcase {...iconProps} />;
    default:
      return <HelpCircle {...iconProps} />;
  }
};

export default CategoryIcon;