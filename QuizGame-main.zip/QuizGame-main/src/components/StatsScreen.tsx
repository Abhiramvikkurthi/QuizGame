import React from 'react';
import { ArrowLeft, Trophy, TrendingUp, Calendar, Target } from 'lucide-react';
import { getGameStats, getBestScore, getAverageScore } from '../utils/storage';

interface StatsScreenProps {
  onBack: () => void;
}

const StatsScreen: React.FC<StatsScreenProps> = ({ onBack }) => {
  const stats = getGameStats();
  const bestScore = getBestScore();
  const averageScore = getAverageScore();
  const totalGames = stats.length;

  // Group stats by set
  const statsBySet = stats.reduce((acc, game) => {
    const setId = game.setId || 0;
    if (!acc[setId]) {
      acc[setId] = {
        setTitle: game.setTitle || 'Unknown Set',
        games: [],
        bestScore: 0,
        averageScore: 0
      };
    }
    acc[setId].games.push(game);
    acc[setId].bestScore = Math.max(acc[setId].bestScore, game.percentage);
    acc[setId].averageScore = Math.round(
      acc[setId].games.reduce((sum, g) => sum + g.percentage, 0) / acc[setId].games.length
    );
    return acc;
  }, {} as Record<number, any>);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="p-2 rounded-lg bg-white dark:bg-gray-800 shadow-md hover:shadow-lg transition-shadow duration-200 mr-4"
          >
            <ArrowLeft className="w-6 h-6 text-gray-600 dark:text-gray-300" />
          </button>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Your Statistics
          </h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <Trophy className="w-8 h-8 text-yellow-500" />
              <span className="text-2xl font-bold text-yellow-500">{bestScore}%</span>
            </div>
            <h3 className="font-semibold text-gray-900 dark:text-white">Best Score</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">Your highest achievement</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <TrendingUp className="w-8 h-8 text-blue-500" />
              <span className="text-2xl font-bold text-blue-500">{averageScore}%</span>
            </div>
            <h3 className="font-semibold text-gray-900 dark:text-white">Average Score</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">Across all games</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <Target className="w-8 h-8 text-green-500" />
              <span className="text-2xl font-bold text-green-500">{totalGames}</span>
            </div>
            <h3 className="font-semibold text-gray-900 dark:text-white">Games Played</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">Total attempts</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <Calendar className="w-8 h-8 text-purple-500" />
              <span className="text-2xl font-bold text-purple-500">
                {Object.keys(statsBySet).length}
              </span>
            </div>
            <h3 className="font-semibold text-gray-900 dark:text-white">Sets Completed</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">Different quiz sets</p>
          </div>
        </div>

        {Object.keys(statsBySet).length > 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Performance by Set</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(statsBySet).map(([setId, setStats]) => (
                <div key={setId} className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                    {setStats.setTitle}
                  </h3>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">
                      Games: {setStats.games.length}
                    </span>
                    <span className="text-green-600 dark:text-green-400">
                      Best: {setStats.bestScore}%
                    </span>
                    <span className="text-blue-600 dark:text-blue-400">
                      Avg: {setStats.averageScore}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Recent Games</h2>
          
          {stats.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-600 dark:text-gray-400">No games played yet</p>
              <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">Start your first quiz to see statistics here</p>
            </div>
          ) : (
            <div className="space-y-4">
              {stats.slice(-10).reverse().map((game, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-white ${
                      game.percentage >= 80 ? 'bg-green-500' : 
                      game.percentage >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}>
                      {game.percentage}%
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">
                        {game.setTitle || 'Quiz Set'}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {game.correctAnswers}/{game.totalQuestions} correct • {new Date(game.completedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                      game.percentage >= 90 ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400' :
                      game.percentage >= 80 ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400' :
                      game.percentage >= 70 ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400' :
                      game.percentage >= 60 ? 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400' :
                      'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400'
                    }`}>
                      {game.percentage >= 90 ? 'Expert' :
                       game.percentage >= 80 ? 'Great' :
                       game.percentage >= 70 ? 'Good' :
                       game.percentage >= 60 ? 'Fair' : 'Needs Practice'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StatsScreen;