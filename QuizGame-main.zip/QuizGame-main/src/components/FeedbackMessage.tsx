import React from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

interface FeedbackMessageProps {
  isCorrect: boolean;
  onNext: () => void;
  isLastQuestion: boolean;
}

const FeedbackMessage: React.FC<FeedbackMessageProps> = ({ isCorrect, onNext, isLastQuestion }) => {
  const messages = {
    correct: [
      "Excellent choice! 🎉",
      "Perfect decision! 👏",
      "You nailed it! ⭐",
      "Great thinking! 💡",
      "Spot on! 🎯"
    ],
    incorrect: [
      "Good try! Learn and grow! 🌱",
      "Next time you'll get it! 💪",
      "Every mistake is a lesson! 📚",
      "Keep learning! 🚀",
      "You're getting better! ⬆️"
    ]
  };

  const messageList = isCorrect ? messages.correct : messages.incorrect;
  const randomMessage = messageList[Math.floor(Math.random() * messageList.length)];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-6 shadow-lg">
      <div className="max-w-2xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {isCorrect ? (
            <CheckCircle className="w-8 h-8 text-green-500" />
          ) : (
            <XCircle className="w-8 h-8 text-red-500" />
          )}
          <span className="text-lg font-semibold text-gray-900 dark:text-white">
            {randomMessage}
          </span>
        </div>
        
        <button
          onClick={onNext}
          className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
        >
          {isLastQuestion ? 'View Results' : 'Next Question'}
        </button>
      </div>
    </div>
  );
};

export default FeedbackMessage;